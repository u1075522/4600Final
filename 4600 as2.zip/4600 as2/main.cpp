#include "GL/glew.h"
#include "GLFW/glfw3.h"
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <stdlib.h>

#define M_PI 3.141592654f

unsigned int g_windowWidth = 600;
unsigned int g_windowHeight = 600;


// here are some variables for Circle and Line mode
bool LineCircle;
bool LineMode;
bool LineFirst;
double x;
double y;
double cx;
double cy;
bool CircleFirst;

char* g_windowName = "HW2-Rasterization";

GLFWwindow* g_window;

const int g_image_width = g_windowWidth;
const int g_image_height = g_windowHeight;

std::vector<float> g_image;

void putPixel(int x, int y)
{
	// clamp
	if (x >= g_image_width || x < 0 || y >= g_image_height || y < 0) return;

	// write
	g_image[y* g_image_width + x] = 1.0f;
}

//-------------------------------------------------------------------------------

void drawLine(int x1, int y1, int x2, int y2)
{
	// if x2 < x1, line is going right to left, swap the start and end points to make the line from
	// left to right
	if (x2 < x1) {
		int temp = 0;
		temp = x2;
		x2 = x1;
		x1 = temp;

		int temp2 = 0;
		temp = y2;
		y2 = y1;
		y1 = temp;
	}


	// this part is when slope is from 0 to 1, 0-45 degree
	if (y2 - y1 >= 0 && y2 - y1 <= x2 - x1) {

		// first get dx, dy, D, inc0, inc1
		float dx = x2 - x1;
		float dy = y2 - y1;
		float D = 2 * dy - dx;
		float inc0 = 2 * dy;
		float inc1 = 2 * (dy - dx);
		// loop through every point 
		while (x1 <= x2) {
			if (D <= 0) {
				D = D + inc0;
			}
			else {
				D = D + inc1;
				y1 = y1 + 1;
			}
		putPixel(x1, y1);
		x1 = x1 + 1;
	}
	return;
	}
	// this part is 45-90 degree
	if (y2 - y1 >= 0 && y2 - y1 > x2 - x1) {
		// record new x2, y2 value and remember old values
		int tempx2 = 0;
		tempx2 = x2;
		int tempx1 = x1;
		int tempy1 = y1;
		int tempy2 = y2;
		x2 = y2 - y1 + x1;
		y2 = tempx2 - x1 + y1;
		// do the same computation
		float dx = x2 - x1;
		float dy = y2 - y1;
		float D = 2 * dy - dx;
		float inc0 = 2 * dy;
		float inc1 = 2 * (dy - dx);
		// loop through all points 
		while (x1 <= x2) {
			if (D <= 0) {
				D = D + inc0;
			}
			else {
				D = D + inc1;
				y1 = y1 + 1;
			}
			putPixel(y1- tempy1 + tempx1, tempy1 + x1 - tempx1);
			x1 = x1 + 1;
		}
		return;
	}
	// this part is when the degree is 0-(-45)
	if (y2 - y1 < 0 && y1 - y2 <= x2 - x1) {
		// first make y2 be positive 
		y2 = y1-y2+y1;
		float tempy1 = y1;
		// get values of useful variables
		float dx = x2 - x1;
		float dy = y2 - y1;
		float D = 2 * dy - dx;
		float inc0 = 2 * dy;
		float inc1 = 2 * (dy - dx);
		// loop through all points
		while (x1 <= x2) {
			if (D <= 0) {
				D = D + inc0;
			}
			else {
				D = D + inc1;
				y1 = y1 + 1;
			}
			putPixel(x1, tempy1-y1 + tempy1);
			x1 = x1 + 1;
		}
		return;
	}

	// this part is when the degree is -45-(-90)
	if (y2 - y1 < 0 && y1 - y2>x2 - x1) {
		//first make y2 be positive 
		y2 = y1 - y2 + y1;
		// record new x2, y2 value and remember old values
		int tempx2 = x2;
		int tempx1 = x1;
		int tempy1 = y1;
		int tempy2 = y2;
		x2 = y2 - y1 + x1;
		y2 = tempx2 - x1 + y1;
		// do the same computation
		float dx = x2 - x1;
		float dy = y2 - y1;
		float D = 2 * dy - dx;
		float inc0 = 2 * dy;
		float inc1 = 2 * (dy - dx);
		while (x1 <= x2) {
			if (D <= 0) {
				D = D + inc0;
			}
			else {
				D = D + inc1;
				y1 = y1 + 1;
			}
			putPixel(y1 - tempy1 + tempx1,tempx1 - x1+tempy1);
			x1 = x1 + 1;
		}
		return;
	}

	// TODO: part of Homework Task 1
	// This function should draw a line from pixel (x1, y1) to pixel (x2, y2)
	
}

// a helper method to draw pixels on the whole circle
void helperCircle(int x0, int y0, int x, int y) {
	putPixel(x0 + x, y0 + y);
	putPixel(x0 - x, y0 + y);
	putPixel(x0 + x, y0 - y);
	putPixel(x0 - x, y0 - y);
	putPixel(x0 + y, y0 + x);
	putPixel(x0 - y, y0 + x);
	putPixel(x0 + y, y0 - x);
	putPixel(x0 - y, y0 - x);

}


void drawCircle(int x0, int y0, int R)
{
	// give value to x,y,D
	int x, y, D;
	x = 0; 
	y = R;
	D = 1-R;
	// first put pixel to verticle lines
	helperCircle(x0, y0, x, y);
	// while loop go through 1/8 of the circle and get the point position
	while (y > x) {
		if (D < 0) {
			D = D + 2 * x + 3;
		}
		else {
			D = D + 2 * (x - y) + 5;
			y = y - 1;
		}		
		x = x + 1;
		helperCircle(x0, y0, x, y);
	}

	// TODO: part of Homework Task 2
	// This function should draw a circle,
	// where pixel (x0, y0) is the center of the circle and R is the radius
	
}





// I'm not using struct line and circle 


struct line
{
	int x1, x2, y1, y2;
	// TODO: part of Homework Task 3


	// This function should initialize the variables of struct line
	void init() { }
	// This function should update the values of member variables and draw a line when 2 points are clicked. 
	void AddPoint(int x, int y) { }
};

struct circle
{
	int x0, y0, R;
	// TODO: part of Homework Task 3
	// This function should initialize the variables of struct circle
	void init() { }
	// This function should update the values of member variables and draw a circle when 2 points are clicked
	// The first clicked point should be the center of the circle
	// The second clicked point should be a point on the circle
	void AddPoint(int x, int y) { }
};

void glfwErrorCallback(int error, const char* description)
{
	std::cerr << "GLFW Error " << error << ": " << description << std::endl;
	exit(1);
}


// this method get the current mode, line or circle
void glfwKeyCallback(GLFWwindow* p_window, int p_key, int p_scancode, int p_action, int p_mods)
{
	if (p_key == GLFW_KEY_ESCAPE && p_action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(g_window, GL_TRUE);
	}
	else if (p_key == GLFW_KEY_L && p_action == GLFW_PRESS)
	{
		std::cout << "Line mode" << std::endl;
		LineMode = true;
		LineFirst = true;
		LineCircle = true;
		CircleFirst = false;
		// TODO: part of Homework Task 3
		// This part switch on the line mode
	}
	else if (p_key == GLFW_KEY_C && p_action == GLFW_PRESS)
	{
		std::cout << "Circle mode" << std::endl;
		LineMode = false;
		LineFirst = false;
		LineCircle = true;
		CircleFirst = true;
		// TODO: part of Homework Task 3
		// This part should switch on the circle mode
	}
}

//!GLFW mouse callback

//this method get the position of the mouse click and do proper action in current mode
void glfwMouseButtonCallback(GLFWwindow* p_window, int p_button, int p_action, int p_mods)
{
	double xpos, ypos;
	glfwGetCursorPos(p_window, &xpos, &ypos);
	ypos = g_windowHeight - ypos;
	if (p_button == GLFW_MOUSE_BUTTON_LEFT && p_action == GLFW_PRESS) 
	{
		std::cout << "You clicked pixel: " << xpos << ", " << ypos << std::endl;
		if (LineCircle == false) {
			putPixel(xpos, ypos);

		}

		// first check if it is in line mode
		else if (LineMode == true && LineCircle == true) {
			// second detect the point you click is the first or second point
			if (LineFirst == true) {
				x = xpos;
				y = ypos;
				putPixel(xpos, ypos);
				LineFirst = false;
			}
			else {
				drawLine(x, y, xpos, ypos);
				putPixel(xpos, ypos);
				LineFirst = true;
			}
			// if they all equal to -1, this will be the first point 
			
		}

		// otherwise, it is in circle mode
		else if (LineMode == false && LineCircle == true) {
			if (CircleFirst == true) {
				cx = xpos;
				cy = ypos;
				putPixel(xpos, ypos);
				CircleFirst = false;
			}
			else {
				double radius = sqrt((xpos - cx) * (xpos - cx) + (ypos - cy) * (ypos - cy));
				drawCircle(cx, cy, radius);
				putPixel(xpos, ypos);
				CircleFirst = true;
			}
		}
		// TODO: part of Homework Task 3
		// This part should draw appropriate figure according to the current mode

	}
}

//-------------------------------------------------------------------------------

struct color
{
	unsigned char r, g, b;
};

int ReadLine(FILE *fp, int size, char *buffer)
{
	int i;
	for (i = 0; i < size; i++) {
		buffer[i] = fgetc(fp);
		if (feof(fp) || buffer[i] == '\n' || buffer[i] == '\r') {
			buffer[i] = '\0';
			return i + 1;
		}
	}
	return i;
}

void initWindow()
{
	// initialize GLFW
	glfwSetErrorCallback(glfwErrorCallback);
	if (!glfwInit())
	{
		std::cerr << "GLFW Error: Could not initialize GLFW library" << std::endl;
		exit(1);
	}

	g_window = glfwCreateWindow(g_windowWidth, g_windowHeight, g_windowName, NULL, NULL);
	if (!g_window)
	{
		glfwTerminate();
		std::cerr << "GLFW Error: Could not initialize window" << std::endl;
		exit(1);
	}

	// callbacks
	glfwSetKeyCallback(g_window, glfwKeyCallback);
	glfwSetMouseButtonCallback(g_window, glfwMouseButtonCallback);

	// Make the window's context current
	glfwMakeContextCurrent(g_window);

	// turn on VSYNC
	glfwSwapInterval(1);
}

void initGL()
{
	glClearColor(1.f, 1.f, 1.f, 1.0f);
}

void render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawPixels(g_image_width, g_image_height, GL_LUMINANCE, GL_FLOAT, &g_image[0]);
}

void renderLoop()
{
	while (!glfwWindowShouldClose(g_window))
	{
		// clear buffers
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		render();

		// Swap front and back buffers
		glfwSwapBuffers(g_window);

		// Poll for and process events
		glfwPollEvents();
	}
}

void initImage()
{
	g_image.resize(g_image_width * g_image_height);
	LineCircle = false;
}

bool writeImage()
{
	std::vector<color> tmpData;
	tmpData.resize(g_image_width * g_image_height);

	for (int i = 0; i < g_image_height; i++)
	{
		for (int j = 0; j < g_image_width; j++)
		{
			// make sure the value will not be larger than 1 or smaller than 0, which might cause problem when converting to unsigned char
			float tmp = g_image[i* g_image_width + j];
			if (tmp < 0.0f)	tmp = 0.0f;
			if (tmp > 1.0f)	tmp = 1.0f;

			tmpData[(g_image_height - i - 1)* g_image_width + j].r = unsigned char(tmp * 255.0);
			tmpData[(g_image_height - i - 1)* g_image_width + j].g = unsigned char(tmp * 255.0);
			tmpData[(g_image_height - i - 1)* g_image_width + j].b = unsigned char(tmp * 255.0);
		}
	}

	FILE *fp = fopen("data/out.ppm", "wb");
	if (!fp) return false;

	fprintf(fp, "P6\r");
	fprintf(fp, "%d %d\r", g_image_width, g_image_height);
	fprintf(fp, "255\r");
	fwrite(tmpData.data(), sizeof(color), g_image_width * g_image_height, fp);
	fclose(fp);

	return true;
}

void drawImage()
{	
	drawLine(150, 10, 450, 10);
	drawLine(150, 310, 450, 310);
	drawLine(150, 10, 150, 310);
	drawLine(450, 10, 450, 310);
	drawLine(150, 310, 300, 410);
	drawLine(300, 410, 450, 310);

	

	drawCircle(500, 500, 50);

}

int main()
{
	initImage();
	drawImage();
	writeImage();

	// render loop
	initWindow();
	initGL();
	renderLoop();

	return 0;
}
